package com.accenture.entity;

public class GameEntity {

}
