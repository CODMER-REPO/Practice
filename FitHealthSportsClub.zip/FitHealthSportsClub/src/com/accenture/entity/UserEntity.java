package com.accenture.entity;



@Entity 

public class UserEntity {
	
	private int userId;
	private String firstName;
	private String lastName;
	private String gender;
	private int contactNumber;
	private String password;
	
	
	
}
