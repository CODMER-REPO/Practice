package com.accenture.dao;

public class Dao {

}
