package com.accenture.service;

public class Service {

}
